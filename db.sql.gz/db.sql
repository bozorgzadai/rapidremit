-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jan 30, 2025 at 05:36 PM
-- Server version: 9.1.0
-- PHP Version: 8.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rapidremit`
--
DROP DATABASE IF EXISTS `rapidremit`;
CREATE DATABASE IF NOT EXISTS `rapidremit` DEFAULT CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci;
USE `rapidremit`;

-- --------------------------------------------------------

--
-- Table structure for table `buy_currency`
--

DROP TABLE IF EXISTS `buy_currency`;
CREATE TABLE IF NOT EXISTS `buy_currency` (
  `buyCurrencyId` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `tel_userId` bigint UNSIGNED DEFAULT NULL,
  `currencyId` int UNSIGNED DEFAULT NULL,
  `time` datetime DEFAULT CURRENT_TIMESTAMP,
  `value` int DEFAULT NULL,
  PRIMARY KEY (`buyCurrencyId`),
  KEY `fk_buycurrency_currency` (`currencyId`),
  KEY `fk_buycurrency_cuser` (`tel_userId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `currency`
--

DROP TABLE IF EXISTS `currency`;
CREATE TABLE IF NOT EXISTS `currency` (
  `currency_id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `currency_name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`currency_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `currency`
--

INSERT INTO `currency` (`currency_id`, `currency_name`) VALUES
(1, 'یورو');

-- --------------------------------------------------------

--
-- Table structure for table `exam`
--

DROP TABLE IF EXISTS `exam`;
CREATE TABLE IF NOT EXISTS `exam` (
  `examId` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `examName` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`examId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `exam_detail`
--

DROP TABLE IF EXISTS `exam_detail`;
CREATE TABLE IF NOT EXISTS `exam_detail` (
  `examDetailId` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `examTypeId` int UNSIGNED DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL,
  `price` int DEFAULT NULL,
  PRIMARY KEY (`examDetailId`),
  KEY `fk_examdetail_examtype` (`examTypeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `exam_type`
--

DROP TABLE IF EXISTS `exam_type`;
CREATE TABLE IF NOT EXISTS `exam_type` (
  `examTypeId` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `examId` int UNSIGNED DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`examTypeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `order_exam`
--

DROP TABLE IF EXISTS `order_exam`;
CREATE TABLE IF NOT EXISTS `order_exam` (
  `orderExamId` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `tel_userId` bigint UNSIGNED DEFAULT NULL,
  `examDetailId` int UNSIGNED DEFAULT NULL,
  `time` datetime DEFAULT CURRENT_TIMESTAMP,
  `description` text,
  `finish` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`orderExamId`),
  KEY `fk_orderexam_examdetail` (`examDetailId`),
  KEY `fk_orderexam_user` (`tel_userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `order_other`
--

DROP TABLE IF EXISTS `order_other`;
CREATE TABLE IF NOT EXISTS `order_other` (
  `orderOtherId` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `tel_userId` bigint UNSIGNED DEFAULT NULL,
  `description` text,
  `time` datetime DEFAULT CURRENT_TIMESTAMP,
  `price` int DEFAULT NULL,
  `finish` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`orderOtherId`),
  KEY `fk_otherexam_user` (`tel_userId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `order_other`
--

INSERT INTO `order_other` (`orderOtherId`, `tel_userId`, `description`, `time`, `price`, `finish`) VALUES
(1, 649100695, 'lre', '2025-01-30 20:42:47', 21, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `tel_userId` bigint UNSIGNED NOT NULL,
  `userName` varchar(30) DEFAULT NULL,
  `userFirstName` varchar(30) DEFAULT NULL,
  `userLastName` varchar(30) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `phoneNumber` varchar(14) DEFAULT NULL,
  `birthDate` date DEFAULT NULL,
  `passport_photo` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`tel_userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`tel_userId`, `userName`, `userFirstName`, `userLastName`, `phoneNumber`, `birthDate`, `passport_photo`) VALUES
(83795243, 'Ali_Ai_Dev', 'Ali', 'Bozorgzad', '2', '0000-00-00', ''),
(649100695, '32', 'Ashkan', NULL, '32', '0000-00-00', '');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `buy_currency`
--
ALTER TABLE `buy_currency`
  ADD CONSTRAINT `fk_buycurrency_currency` FOREIGN KEY (`currencyId`) REFERENCES `currency` (`currency_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `fk_buycurrency_cuser` FOREIGN KEY (`tel_userId`) REFERENCES `user` (`tel_userId`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Constraints for table `exam_detail`
--
ALTER TABLE `exam_detail`
  ADD CONSTRAINT `fk_examdetail_examtype` FOREIGN KEY (`examTypeId`) REFERENCES `exam_type` (`examTypeId`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Constraints for table `exam_type`
--
ALTER TABLE `exam_type`
  ADD CONSTRAINT `fk_examtype_exam` FOREIGN KEY (`examTypeId`) REFERENCES `exam` (`examId`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Constraints for table `order_exam`
--
ALTER TABLE `order_exam`
  ADD CONSTRAINT `fk_orderexam_examdetail` FOREIGN KEY (`examDetailId`) REFERENCES `exam_detail` (`examDetailId`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `fk_orderexam_user` FOREIGN KEY (`tel_userId`) REFERENCES `user` (`tel_userId`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Constraints for table `order_other`
--
ALTER TABLE `order_other`
  ADD CONSTRAINT `fk_otherexam_user` FOREIGN KEY (`tel_userId`) REFERENCES `user` (`tel_userId`) ON DELETE RESTRICT ON UPDATE RESTRICT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
