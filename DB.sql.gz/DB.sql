-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Mar 11, 2025 at 06:16 AM
-- Server version: 9.1.0
-- PHP Version: 8.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rapidremit`
--
DROP DATABASE IF EXISTS `rapidremit`;
CREATE DATABASE IF NOT EXISTS `rapidremit` DEFAULT CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci;
USE `rapidremit`;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `adminId` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `tel_userId` bigint UNSIGNED DEFAULT NULL,
  PRIMARY KEY (`adminId`),
  KEY `fk_admin_user` (`tel_userId`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adminId`, `tel_userId`) VALUES
(1, 83795243),
(2, 649100695),
(3, 6825575713),
(4, 7044152693);

-- --------------------------------------------------------

--
-- Table structure for table `app_fee`
--

DROP TABLE IF EXISTS `app_fee`;
CREATE TABLE IF NOT EXISTS `app_fee` (
  `appFeeId` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `tel_userId` bigint UNSIGNED DEFAULT NULL,
  `university` varchar(40) DEFAULT NULL,
  `degree` varchar(50) DEFAULT NULL,
  `euroAmount` int DEFAULT NULL,
  `euroPrice` int DEFAULT NULL,
  `rialChange` int DEFAULT NULL,
  `trans_filepath` varchar(50) DEFAULT NULL,
  `time` datetime DEFAULT CURRENT_TIMESTAMP,
  `finish` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`appFeeId`),
  KEY `fk_appFee_user` (`tel_userId`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `buy_currency`
--

DROP TABLE IF EXISTS `buy_currency`;
CREATE TABLE IF NOT EXISTS `buy_currency` (
  `buyCurrencyId` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `tel_userId` bigint UNSIGNED DEFAULT NULL,
  `currencyId` int UNSIGNED DEFAULT NULL,
  `time` datetime DEFAULT CURRENT_TIMESTAMP,
  `value` int DEFAULT NULL,
  `finish` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`buyCurrencyId`),
  KEY `fk_buycurrency_currency` (`currencyId`),
  KEY `fk_buycurrency_cuser` (`tel_userId`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `cimea`
--

DROP TABLE IF EXISTS `cimea`;
CREATE TABLE IF NOT EXISTS `cimea` (
  `cimeaId` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `tel_userId` bigint UNSIGNED DEFAULT NULL,
  `cimeaPriceId` int UNSIGNED DEFAULT NULL,
  `trans_filepath` varchar(50) DEFAULT NULL,
  `time` datetime DEFAULT CURRENT_TIMESTAMP,
  `finish` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`cimeaId`),
  KEY `fk_cimea_user` (`tel_userId`),
  KEY `fk_cimea_cimeaprice` (`cimeaPriceId`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `cimea_price`
--

DROP TABLE IF EXISTS `cimea_price`;
CREATE TABLE IF NOT EXISTS `cimea_price` (
  `cimeaPriceId` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `cimeaTypeId` int UNSIGNED DEFAULT NULL,
  `cimeaSpeedId` int UNSIGNED DEFAULT NULL,
  `cimeaPrice` int DEFAULT NULL,
  PRIMARY KEY (`cimeaPriceId`),
  KEY `fk_cimeaprice_cimeatype` (`cimeaTypeId`),
  KEY `fk_cimeaprice_cimeaspeed` (`cimeaSpeedId`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `cimea_price`
--

INSERT INTO `cimea_price` (`cimeaPriceId`, `cimeaTypeId`, `cimeaSpeedId`, `cimeaPrice`) VALUES
(3, 2, 1, 21),
(4, 2, 2, 22);

-- --------------------------------------------------------

--
-- Table structure for table `cimea_speed`
--

DROP TABLE IF EXISTS `cimea_speed`;
CREATE TABLE IF NOT EXISTS `cimea_speed` (
  `cimeaSpeedId` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `cimeaSpeedName` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`cimeaSpeedId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `cimea_speed`
--

INSERT INTO `cimea_speed` (`cimeaSpeedId`, `cimeaSpeedName`) VALUES
(1, 'عادی'),
(2, 'فوری');

-- --------------------------------------------------------

--
-- Table structure for table `cimea_type`
--

DROP TABLE IF EXISTS `cimea_type`;
CREATE TABLE IF NOT EXISTS `cimea_type` (
  `cimeaTypeId` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `cimeaTypeName` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`cimeaTypeId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `cimea_type`
--

INSERT INTO `cimea_type` (`cimeaTypeId`, `cimeaTypeName`) VALUES
(2, 'comparability');

-- --------------------------------------------------------

--
-- Table structure for table `cisia_account`
--

DROP TABLE IF EXISTS `cisia_account`;
CREATE TABLE IF NOT EXISTS `cisia_account` (
  `cisiaAccountId` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `tel_userId` bigint UNSIGNED DEFAULT NULL,
  `username` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `password` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  PRIMARY KEY (`cisiaAccountId`),
  KEY `fk_cisiaaccount_user` (`tel_userId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `currency`
--

DROP TABLE IF EXISTS `currency`;
CREATE TABLE IF NOT EXISTS `currency` (
  `currency_id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `currency_name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`currency_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `currency`
--

INSERT INTO `currency` (`currency_id`, `currency_name`) VALUES
(1, 'یورو');

-- --------------------------------------------------------

--
-- Table structure for table `order_other`
--

DROP TABLE IF EXISTS `order_other`;
CREATE TABLE IF NOT EXISTS `order_other` (
  `orderOtherId` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `tel_userId` bigint UNSIGNED DEFAULT NULL,
  `description` text,
  `time` datetime DEFAULT CURRENT_TIMESTAMP,
  `price` int DEFAULT NULL,
  `finish` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`orderOtherId`),
  KEY `fk_otherexam_user` (`tel_userId`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `reg_course_lang`
--

DROP TABLE IF EXISTS `reg_course_lang`;
CREATE TABLE IF NOT EXISTS `reg_course_lang` (
  `regCourseLangId` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `regCourseLangName` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`regCourseLangId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `reg_course_lang`
--

INSERT INTO `reg_course_lang` (`regCourseLangId`, `regCourseLangName`) VALUES
(1, 'English'),
(2, 'Italian'),
(3, 'ترکیبی');

-- --------------------------------------------------------

--
-- Table structure for table `reg_course_level`
--

DROP TABLE IF EXISTS `reg_course_level`;
CREATE TABLE IF NOT EXISTS `reg_course_level` (
  `regCourseLevelId` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `regCourseLevelName` varchar(30) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  PRIMARY KEY (`regCourseLevelId`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `reg_course_level`
--

INSERT INTO `reg_course_level` (`regCourseLevelId`, `regCourseLevelName`) VALUES
(1, 'لیسانس'),
(2, 'کارشناسی ارشد'),
(3, 'سینگل کورس'),
(4, 'single cycle'),
(5, 'other');

-- --------------------------------------------------------

--
-- Table structure for table `reg_type`
--

DROP TABLE IF EXISTS `reg_type`;
CREATE TABLE IF NOT EXISTS `reg_type` (
  `regTypeId` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `regTypeName` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`regTypeId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `reg_type`
--

INSERT INTO `reg_type` (`regTypeId`, `regTypeName`) VALUES
(1, 'Enrollment (پس از قبولی)'),
(2, 'Apply (پیش از پذیرش)');

-- --------------------------------------------------------

--
-- Table structure for table `reg_uni`
--

DROP TABLE IF EXISTS `reg_uni`;
CREATE TABLE IF NOT EXISTS `reg_uni` (
  `regUniId` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `tel_userId` bigint UNSIGNED DEFAULT NULL,
  `regTypeId` int UNSIGNED DEFAULT NULL,
  `regCourseLevelId` int UNSIGNED DEFAULT NULL,
  `regCourseLangId` int UNSIGNED DEFAULT NULL,
  `uniName` varchar(50) DEFAULT NULL,
  `courseName` varchar(50) DEFAULT NULL,
  `time` datetime DEFAULT CURRENT_TIMESTAMP,
  `finish` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`regUniId`),
  KEY `fk_regUni_user` (`tel_userId`),
  KEY `fk_regUni_regType` (`regTypeId`),
  KEY `fk_regUni_regCourseLevel` (`regCourseLevelId`),
  KEY `fk_regUni_regCourseLang` (`regCourseLangId`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `reserve_hotel`
--

DROP TABLE IF EXISTS `reserve_hotel`;
CREATE TABLE IF NOT EXISTS `reserve_hotel` (
  `reserveHotelID` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `tel_userId` bigint UNSIGNED DEFAULT NULL,
  `time` datetime DEFAULT CURRENT_TIMESTAMP,
  `finish` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`reserveHotelID`),
  KEY `fk_reservehotel_user` (`tel_userId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `tolc_exam_detail`
--

DROP TABLE IF EXISTS `tolc_exam_detail`;
CREATE TABLE IF NOT EXISTS `tolc_exam_detail` (
  `tolcExamDetailId` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `tolcExamTypeId` int UNSIGNED DEFAULT NULL,
  `tolcExamDetailName` varchar(30) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  PRIMARY KEY (`tolcExamDetailId`),
  KEY `fk_tolcexamdetail_tolcexamtype` (`tolcExamTypeId`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `tolc_exam_detail`
--

INSERT INTO `tolc_exam_detail` (`tolcExamDetailId`, `tolcExamTypeId`, `tolcExamDetailName`) VALUES
(1, 2, 'ENGLISH TOLC-I'),
(2, 2, 'TOLC-I'),
(3, 3, 'ENGLISH TOLC-F'),
(4, 3, 'TOLC-F'),
(5, 4, 'ENGLISH TOLC-E'),
(6, 4, 'TOLC-E'),
(8, 5, 'TOLC-S'),
(10, 6, 'TOLC-SU'),
(12, 7, 'TOLC-B'),
(14, 8, 'TOLC-AV'),
(16, 9, 'TOLC-PSi'),
(18, 10, 'TOLC-SB'),
(20, 11, 'TOLC-LP');

-- --------------------------------------------------------

--
-- Table structure for table `tolc_exam_type`
--

DROP TABLE IF EXISTS `tolc_exam_type`;
CREATE TABLE IF NOT EXISTS `tolc_exam_type` (
  `tolcExamTypeId` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `tolcExamTypeName` varchar(30) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  PRIMARY KEY (`tolcExamTypeId`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `tolc_exam_type`
--

INSERT INTO `tolc_exam_type` (`tolcExamTypeId`, `tolcExamTypeName`) VALUES
(2, 'TOLC-I'),
(3, 'TOLC-F'),
(4, 'TOLC-E'),
(5, 'TOLC-S'),
(6, 'TOLC-SU'),
(7, 'TOLC-B'),
(8, 'TOLC-AV'),
(9, 'TOLC-PSi'),
(10, 'TOLC-SB'),
(11, 'TOLC-LP');

-- --------------------------------------------------------

--
-- Table structure for table `tolc_order_exam`
--

DROP TABLE IF EXISTS `tolc_order_exam`;
CREATE TABLE IF NOT EXISTS `tolc_order_exam` (
  `tolcOrderExamId` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `tel_userId` bigint UNSIGNED DEFAULT NULL,
  `tolcExamDetailId` int UNSIGNED DEFAULT NULL,
  `examDate` varchar(100) DEFAULT NULL,
  `trans_filePath` varchar(50) DEFAULT NULL,
  `time` datetime DEFAULT CURRENT_TIMESTAMP,
  `finish` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`tolcOrderExamId`),
  KEY `fk_orderexam_examdetail` (`tolcExamDetailId`),
  KEY `fk_orderexam_user` (`tel_userId`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `torvergata`
--

DROP TABLE IF EXISTS `torvergata`;
CREATE TABLE IF NOT EXISTS `torvergata` (
  `torvergataId` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `tel_userId` bigint UNSIGNED DEFAULT NULL,
  `trans_filepath` varchar(50) DEFAULT NULL,
  `time` datetime DEFAULT CURRENT_TIMESTAMP,
  `finish` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`torvergataId`),
  KEY `fk_torvergata_user` (`tel_userId`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `tuition_fee`
--

DROP TABLE IF EXISTS `tuition_fee`;
CREATE TABLE IF NOT EXISTS `tuition_fee` (
  `tuitionFeeId` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `tel_userId` bigint UNSIGNED DEFAULT NULL,
  `university` varchar(40) DEFAULT NULL,
  `degree` varchar(50) DEFAULT NULL,
  `time` datetime DEFAULT CURRENT_TIMESTAMP,
  `finish` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`tuitionFeeId`),
  KEY `fk_tuitionFee_user` (`tel_userId`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `tel_userId` bigint UNSIGNED NOT NULL,
  `userName` varchar(30) DEFAULT NULL,
  `userFirstName` varchar(30) DEFAULT NULL,
  `userLastName` varchar(30) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `phoneNumber` varchar(14) DEFAULT NULL,
  `birthDate` date DEFAULT NULL,
  `passport_photo` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`tel_userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`tel_userId`, `userName`, `userFirstName`, `userLastName`, `phoneNumber`, `birthDate`, `passport_photo`) VALUES
(83795243, 'Ali_Ai_Dev', 'Ali', 'Bozorgzad', '7890', '0000-00-00', ''),
(649100695, 'Jejs', 'Ashkan', NULL, 'Dkks', '0000-00-00', ''),
(6825575713, 'faren_abdolahi', 'Faren', 'Abdollahai', ' ', '0000-00-00', ''),
(7044152693, 'Programmer_project', 'Ashkan', 'H', ' ', '0000-00-00', '');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `admin`
--
ALTER TABLE `admin`
  ADD CONSTRAINT `fk_admin_user` FOREIGN KEY (`tel_userId`) REFERENCES `user` (`tel_userId`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Constraints for table `app_fee`
--
ALTER TABLE `app_fee`
  ADD CONSTRAINT `fk_appFee_user` FOREIGN KEY (`tel_userId`) REFERENCES `user` (`tel_userId`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Constraints for table `buy_currency`
--
ALTER TABLE `buy_currency`
  ADD CONSTRAINT `fk_buycurrency_currency` FOREIGN KEY (`currencyId`) REFERENCES `currency` (`currency_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `fk_buycurrency_user` FOREIGN KEY (`tel_userId`) REFERENCES `user` (`tel_userId`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Constraints for table `cimea`
--
ALTER TABLE `cimea`
  ADD CONSTRAINT `fk_cimea_cimeaprice` FOREIGN KEY (`cimeaPriceId`) REFERENCES `cimea_price` (`cimeaPriceId`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `fk_cimea_user` FOREIGN KEY (`tel_userId`) REFERENCES `user` (`tel_userId`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Constraints for table `cimea_price`
--
ALTER TABLE `cimea_price`
  ADD CONSTRAINT `fk_cimeaprice_cimeaspeed` FOREIGN KEY (`cimeaSpeedId`) REFERENCES `cimea_speed` (`cimeaSpeedId`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `fk_cimeaprice_cimeatype` FOREIGN KEY (`cimeaTypeId`) REFERENCES `cimea_type` (`cimeaTypeId`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Constraints for table `cisia_account`
--
ALTER TABLE `cisia_account`
  ADD CONSTRAINT `fk_cisiaaccount_user` FOREIGN KEY (`tel_userId`) REFERENCES `user` (`tel_userId`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Constraints for table `order_other`
--
ALTER TABLE `order_other`
  ADD CONSTRAINT `fk_otherexam_user` FOREIGN KEY (`tel_userId`) REFERENCES `user` (`tel_userId`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Constraints for table `reg_uni`
--
ALTER TABLE `reg_uni`
  ADD CONSTRAINT `fk_regUni_regCourseLang` FOREIGN KEY (`regCourseLangId`) REFERENCES `reg_course_lang` (`regCourseLangId`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `fk_regUni_regCourseLevel` FOREIGN KEY (`regCourseLevelId`) REFERENCES `reg_course_level` (`regCourseLevelId`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `fk_regUni_regType` FOREIGN KEY (`regTypeId`) REFERENCES `reg_type` (`regTypeId`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `fk_regUni_user` FOREIGN KEY (`tel_userId`) REFERENCES `user` (`tel_userId`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Constraints for table `reserve_hotel`
--
ALTER TABLE `reserve_hotel`
  ADD CONSTRAINT `fk_reservehotel_user` FOREIGN KEY (`tel_userId`) REFERENCES `user` (`tel_userId`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Constraints for table `tolc_exam_detail`
--
ALTER TABLE `tolc_exam_detail`
  ADD CONSTRAINT `fk_tolcexamdetail_tolcexamtype` FOREIGN KEY (`tolcExamTypeId`) REFERENCES `tolc_exam_type` (`tolcExamTypeId`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Constraints for table `tolc_order_exam`
--
ALTER TABLE `tolc_order_exam`
  ADD CONSTRAINT `fk_orderexam_examdetail` FOREIGN KEY (`tolcExamDetailId`) REFERENCES `tolc_exam_detail` (`tolcExamDetailId`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `fk_orderexam_user` FOREIGN KEY (`tel_userId`) REFERENCES `user` (`tel_userId`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Constraints for table `torvergata`
--
ALTER TABLE `torvergata`
  ADD CONSTRAINT `fk_torvergata_user` FOREIGN KEY (`tel_userId`) REFERENCES `user` (`tel_userId`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Constraints for table `tuition_fee`
--
ALTER TABLE `tuition_fee`
  ADD CONSTRAINT `fk_tuitionFee_user` FOREIGN KEY (`tel_userId`) REFERENCES `user` (`tel_userId`) ON DELETE RESTRICT ON UPDATE RESTRICT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
